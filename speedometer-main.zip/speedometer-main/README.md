# speedometer
check the speed of the ball in cricket match
